# Python example - Fourier transform using numpy.fft method

import numpy as np

import matplotlib.pyplot as plotter

# How many time points are needed i,e., Sampling Frequency

samplingFrequency = 100

# At what intervals time points are sampled

samplingInterval = 1 / samplingFrequency

# Begin time period of the signals

beginTime = 0

# End time period of the signals

endTime = 10

# Frequency of the signals

signal1Frequency = 4

signal2Frequency = 6

# Time points

time = np.arange(beginTime, endTime, samplingInterval)

# Create two sine waves
# print(time)
amplitude1 = np.sin(2 * np.pi * signal1Frequency * time)


amplitude2 = np.sin(2 * np.pi * signal2Frequency * time)
# amplitude2 = [ round(elem, 2) for elem in amplitude2 ]
# amplitude1 = [ round(elem, 2) for elem in amplitude1 ]
# import numpy as np
myList1 = list(np.around(np.array(amplitude1),2))
myList2 = list(np.around(np.array(amplitude2),2))

# Create subplot

figure, axis = plotter.subplots(4, 1)

plotter.subplots_adjust(hspace=1)

# Time domain representation for sine wave 1

axis[0].set_title('Sine wave with a frequency of 4 Hz')

axis[0].plot(time, amplitude1)

axis[0].set_xlabel('Time')

axis[0].set_ylabel('Amplitude')

# Time domain representation for sine wave 2

axis[1].set_title('Sine wave with a frequency of 7 Hz')

axis[1].plot(time, amplitude2)

axis[1].set_xlabel('Time')

axis[1].set_ylabel('Amplitude')

# Add the sine waves

amplitude = amplitude1 + amplitude2

# Time domain representation of the resultant sine wave

axis[2].set_title('Sine wave with multiple frequencies')

axis[2].plot(time, amplitude)

axis[2].set_xlabel('Time')

axis[2].set_ylabel('Amplitude')

# Frequency domain representation

fourierTransform = np.fft.fft(amplitude) / len(amplitude)  # Normalize amplitude
#print(fourierTransform)
fourierTransform = fourierTransform[range(int(len(amplitude) / 2))]  # Exclude sampling frequency

tpCount = len(amplitude)

values = np.arange(int(tpCount / 2))

timePeriod = tpCount / samplingFrequency

frequencies = values / timePeriod

# Frequency domain representation

axis[3].set_title('Fourier transform depicting the frequency components')

axis[3].plot(frequencies, abs(fourierTransform))

axis[3].set_xlabel('Frequency')

axis[3].set_ylabel('Amplitude')


print(len(fourierTransform))
import pandas
df = pandas.DataFrame(data={"col1": time, "col2": amplitude1, "col3":amplitude2, "col4":myList1, "col5":myList2, })
df.to_csv("file212.csv", sep=',',index=False)

df = pandas.DataFrame(data={"frequencies": frequencies, "fourierTransform": fourierTransform, "abs(fourierTransform) ": abs(fourierTransform), "abs(fourierTransform) ": abs(fourierTransform) })
df.to_csv("freq_domain.csv", sep=',',index=False)


df = pandas.DataFrame(data={"time": time, "amplitude1":amplitude1})
df.to_csv("time_domain.csv", sep=',',index=False)

# plotter.show()
import sys

local_vars = list(locals().items())

for var, obj in local_vars:
    print(var)


df = pandas.DataFrame(data={"col1": abs(np.fft.fft(amplitude))})
df.to_csv("file44.csv", sep=',',index=False)
#
# print("np ", np)
# print("plotter ", plotter)
# print("samplingFrequency ", samplingFrequency)
# print("samplingInterval ", samplingInterval)
# print("beginTime ", beginTime)
# print("endTime ", endTime)
# print("signal1Frequency ", signal1Frequency)
# print("signal2Frequency ", signal2Frequency)
# print("time ", time)
# print("amplitude1 ", amplitude1)
# print("amplitude2 ", amplitude2)
# print("myList1 ", myList1)
# print("myList2 ", myList2)
# print("figure ", figure)
# print("axis ", axis)
# print("amplitude ", amplitude)
# print("fourierTransform ", fourierTransform)
# print("abs fourierTransform ", abs(fourierTransform))
# print("tpCount ", tpCount)
# print("values ", values)
# print("timePeriod ", timePeriod)
# print("frequencies ", frequencies)
# print("pandas ", pandas)
# print("df ", df)
# print("sys ", sys)
# print("time length = ", len(time))
# print("amp1 length = ", len(amplitude1))
# print("amp1 length = ", len(amplitude1))
# print("amp  length = ", len(amplitude))
# print("fourierTransform  length = ", len(fourierTransform))
# print("fourierTransform  length = ", len(frequencies))