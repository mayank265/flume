import numpy as np
input_filename='FFT_sample.csv'
t, u, v, w = np.loadtxt(input_filename, dtype=float, delimiter=',',
                                                                  skiprows=1,
                                                                  usecols=(0, 1,2,3) ,
                                                                  unpack=True)

print(t, u, v, w)
print(type(u))