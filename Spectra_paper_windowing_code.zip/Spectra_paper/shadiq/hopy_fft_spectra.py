import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft, ifft
import pandas as pd
import csv
import sys


def fft_module_individual(filename_read, column_header, color_choice):


    df = pd.read_csv(filename_read)
    df.dropna(inplace=True)
    print(column_header)
    u_amplitude = df[column_header].tolist()
    print(u_amplitude)
    u_amplitude_numpy_array = np.asarray(u_amplitude)
    print(u_amplitude_numpy_array)
    percentage = 10
    frequency = 100


    #Number of samples, 10 percent we are taking as of now
    N = int(len(u_amplitude) * (percentage / 100))
    T = 1 / frequency
    xf = np.linspace(0.0, 1.0 / (2 * T), N // 2)  # 0, ,10
    print(xf, len(xf), N // 2)

    amplitude_under_considertion = u_amplitude[:N]
    y = amplitude_under_considertion

    fourier_amplitude = fft(y)
    my_list = 2.0 / N * np.abs(fourier_amplitude[0:N // 2]) #Excluding Sampling Frequency
    plt.clf()
    plt.loglog(xf, my_list, color=color_choice, label=str(column_header)+' Amplitude')
    plt.legend()


    plt.grid()
    plt.xlabel('Frequency')
    plt.ylabel('Peaks')
    # plt.savefig(image_filename_write)
    plt.show()
    # plt.clf()


filename_read = 'FFT_sample.csv'
column_header = ['u']
colors = ["blue"]
for i, j in zip(column_header, colors):
    fft_module_individual(filename_read, i, j)