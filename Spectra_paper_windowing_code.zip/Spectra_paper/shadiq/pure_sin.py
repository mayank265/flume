import numpy as np
from scipy.fftpack import fft, ifft
import pandas as pd
import csv
import sys
import matplotlib.pyplot as plt


input_filename='sine_wave.csv'
time, amplitude = np.loadtxt(input_filename, dtype=float, delimiter=',',
                                                                  skiprows=1,
                                                                  usecols=(0, 1 ) ,
                                                                  unpack=True)

import numpy as np
import math

in_array = [0, math.pi / 2, np.pi / 3, np.pi]
print("Input array : \n", in_array)

Sin_Values = np.sin(in_array)
print("\nSine values : \n", Sin_Values)

print(time, amplitude)
t=time

# How many time points are needed i,e., Sampling Frequency
samplingFrequency = 100

# At what intervals time points are sampled
samplingInterval = 1 / samplingFrequency

# Begin time period of the signals
#print(t[0], t[-1])  Start Time and End time
beginTime = t[0]

# End time period of the signals
endTime = t[-1]


# Time points
time = np.arange(beginTime, endTime, samplingInterval)

y = fft(amplitude)
print(y)

