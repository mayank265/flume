import numpy as np
import matplotlib.pyplot as plt
from scipy.fftpack import fft, ifft
import pandas as pd
import csv
import sys

def fft_module_individual(filename_read, column_header, color_choice):

    header = ['Freq', 'Amplitude']
    # filename_read = 'FFT_sample.csv'
    # column_header = 'u'
    # color_choice='red'
    data_filename_write = filename_read.split('.')[0] + '_Column_Header_' + column_header + '_FFT_Data.csv'
    image_filename_write = filename_read.split('.')[0] + '_Column_Header_' + column_header + '_FFT_Spectra.jpg'

    df = pd.read_csv(filename_read)
    df.dropna(inplace=True)
    print(column_header)
    u_list = df[column_header].tolist()
    column_to_numpy_array = np.asarray(u_list)
    slice_of_input_array_for_processing_FFT = []

    # percentage = float(
    #     input(
    #         "Enter the % number of samples for FFT Calculation (default 10 percent). Press Enter to accept default : ") or "10")
    #
    # frequency = int(input("Enter the sampling frequency: "))

    percentage = 10
    frequency = 100

    N = int(len(u_list) * (percentage / 100))

    # num_samples = 3000
    for i in range(0, N):
        slice_of_input_array_for_processing_FFT.append(column_to_numpy_array[i])

    # frequency of signal
    T = 1 / frequency
    # x=np.linspace(0,N*T,N)#0, ,21
    y = slice_of_input_array_for_processing_FFT
    ####### processs via window  y = windowing(y)
    yf = fft(y)

    xf = np.linspace(0.0, 1.0 / (2 * T), N // 2)  # 0, ,10
    my_list = 2.0 / N * np.abs(yf[0:N // 2])

    with open(data_filename_write, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(i for i in header)
        writer.writerows(zip(xf, my_list))

    import sys

    local_vars = list(locals().items())

    for var, obj in local_vars:
        print(var)

    print("filename_read = ", filename_read)
    print("length of filename_read = ", len(filename_read))
    print("column_header = ", column_header)
    print("length of column_header = ", len(column_header))
    print("color_choice = ", color_choice)
    print("length of color_choice = ", len(color_choice))
    print("header = ", header)
    print("length of header = ", len(header))
    print("data_filename_write = ", data_filename_write)
    print("length of data_filename_write = ", len(data_filename_write))
    print("image_filename_write = ", image_filename_write)
    print("length of image_filename_write = ", len(image_filename_write))
    print("df = ", df)
    print("length of df = ", len(df))
    print("u_list = ", u_list)
    print("length of u_list = ", len(u_list))
    print("column_to_numpy_array = ", column_to_numpy_array)
    print("length of column_to_numpy_array = ", len(column_to_numpy_array))
    print("slice_of_input_array_for_processing_FFT = ", slice_of_input_array_for_processing_FFT)
    print("length of slice_of_input_array_for_processing_FFT = ", len(slice_of_input_array_for_processing_FFT))
    print("percentage = ", percentage)
    # print("length of percentage = ", len(percentage) or 0)
    print("frequency = ", frequency)
    # print("length of frequency = ", len(frequency))
    print("N = ", N)
    # print("length of N = ", len(N))
    print("i = ", i)
    # print("length of i = ", len(i))
    print("T = ", T)
    # print("length of T = ", len(T))
    print("y = ", y)
    print("length of y = ", len(y))
    print("yf = ", yf)
    print("length of yf = ", len(yf))
    print("xf = ", xf)
    print("length of xf = ", len(xf))
    print("my_list = ", my_list)
    print("length of my_list = ", len(my_list))
    print("f = ", f)
    # print("length of f = ", len(f))
    print("writer = ", writer)

    plt.clf()
    plt.loglog(xf, 2.0 / N * np.abs(yf[0:N // 2]), color=color_choice, label=str(column_header)+' Amplitude')
    plt.legend()


    plt.grid()
    plt.xlabel('Frequency')
    plt.ylabel('Peaks')
    plt.savefig(image_filename_write)
    # plt.show()
    plt.clf()



filename_read = 'FFT_sample.csv'
column_header = ['u']
colors = ["red"]
for i, j in zip(column_header, colors):
    fft_module_individual(filename_read, i, j)
#
