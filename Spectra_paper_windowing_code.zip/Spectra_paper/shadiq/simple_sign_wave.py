# Python example - Fourier transform using numpy.fft method
import numpy as np
from scipy.fftpack import fft, ifft
import pandas as pd
import csv
import sys
#https://flothesof.github.io/FFT-window-properties-frequency-analysis.html

import numpy as np

import matplotlib.pyplot as plotter

def fft_calucation(amplitude, samplingFrequency):
    fourierTransform = np.fft.fft(amplitude) / len(amplitude)  # Normalize amplitude
    # print(fourierTransform)
    fourierTransform = fourierTransform[range(int(len(amplitude) / 2))]  # Exclude sampling frequency
    tpCount = len(amplitude)
    values = np.arange(int(tpCount / 2))
    timePeriod = tpCount / samplingFrequency
    frequencies = values / timePeriod
    return  fourierTransform, frequencies

input_filename='FFT_sample.csv'
t, u, v, w = np.loadtxt(input_filename, dtype=float, delimiter=',',
                                                                  skiprows=1,
                                                                  usecols=(0, 1,2,3) ,
                                                                  unpack=True)

# How many time points are needed i,e., Sampling Frequency
samplingFrequency = 100

# At what intervals time points are sampled
samplingInterval = 1 / samplingFrequency

# Begin time period of the signals
#print(t[0], t[-1])  Start Time and End time
beginTime = t[0]

# End time period of the signals
endTime = t[-1]


# Time points
time = np.arange(beginTime, endTime, samplingInterval)

# Create two sine waves
# print(time)
percent = 25
amplitude1 = u[:int(len(u)*percent/100)]

myList1 = list(np.around(np.array(amplitude1),2))
amplitude1 = myList1
# Create subplot

figure, axis = plotter.subplots(4, 1)

plotter.subplots_adjust(hspace=1)

# Time domain representation for sine wave 1

axis[0].set_title('Sine wave with a frequency of 4 Hz')

min_len = min(len(time), len(amplitude1))
print(min_len)
axis[0].plot(time[:min_len], amplitude1[:min_len])
axis[0].set_xlabel('Time')
axis[0].set_ylabel('Amplitude')

# Time domain representation for sine wave 2
#
# axis[1].set_title('Sine wave with a frequency of 7 Hz')
#
# axis[1].plot(time, amplitude2)
#
# axis[1].set_xlabel('Time')
#
# axis[1].set_ylabel('Amplitude')
#
# # Add the sine waves
#
# amplitude = amplitude1 + amplitude2
#
# # Time domain representation of the resultant sine wave
#
# axis[2].set_title('Sine wave with multiple frequencies')
#
# axis[2].plot(time, amplitude)
#
# axis[2].set_xlabel('Time')
#
# axis[2].set_ylabel('Amplitude')

# Frequency domain representation
amplitude=amplitude1

fourierTransform,  frequencies = fft_calucation(amplitude, samplingFrequency)
# Frequency domain representation

axis[3].set_title('Fourier transform depicting the frequency components')

axis[3].loglog(frequencies, abs(fourierTransform))

# plt.loglog(xf, 2.0 / N * np.abs(yf[0:N // 2]), color=color_choice, label=str(column_header) + ' Amplitude')


axis[3].set_xlabel('Frequency')

axis[3].set_ylabel('Amplitude')


plotter.show()