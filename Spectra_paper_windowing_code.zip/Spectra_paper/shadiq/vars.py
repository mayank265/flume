with open("var.txt","r") as f:
    lines=f.readlines()
    for line in lines:
        # print(line)
        var_read = 'print("' + str(line.strip()) + ' = ",' + str(line.strip()) + ')'
        print(var_read)
        len_var_read = 'print("length of ' + str(line.strip()) + ' = ", len(' + str(line.strip()) + '))'
        print(len_var_read)