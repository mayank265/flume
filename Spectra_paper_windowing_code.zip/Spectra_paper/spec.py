from spectrum.window import window_hamming
from pylab import *

N = 64
w = window_hamming(N)
plot(w)
show()