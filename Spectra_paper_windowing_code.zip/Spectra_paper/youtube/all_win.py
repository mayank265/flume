import numpy as np
import matplotlib.pyplot as plt
import csv
import pandas

plt.rcParams['figure.figsize'] = [12, 8]

dt = 0.01  # 1/dt = Frequency
total_time_length_of_singal_in_seconds = np.arange(0, 10, dt)
n = len(total_time_length_of_singal_in_seconds)

amplitude =  np.sin(2 * np.pi * 30 * total_time_length_of_singal_in_seconds)
fft_amplitude = np.fft.fft(amplitude, n)
absolute_fft = abs(fft_amplitude)

freq_range_points = (1 / (dt * n)) * np.arange(n)  # freq is always 1/dt, but the granularity changes based on the time range of the we are inputting.

L = np.arange(1, np.floor((n / 2)), dtype='int')  # Plot half only as its mirror image

print(len(total_time_length_of_singal_in_seconds), len(amplitude), len(fft_amplitude), len(freq_range_points),
      (freq_range_points[L[-1]]), len(L))

df = pandas.DataFrame(
    data={"Time": total_time_length_of_singal_in_seconds, "Amplitude": amplitude, "FFT": fft_amplitude,
          "abs_FFT": absolute_fft, "frequency": freq_range_points})
df.to_csv("simplest_fft.csv", sep=',', index=False)
fig, axs = plt.subplots(4, 1)

plt.sca(axs[0])
plt.plot(total_time_length_of_singal_in_seconds, amplitude, color='c', label='Clean')
plt.xlim(total_time_length_of_singal_in_seconds[0], total_time_length_of_singal_in_seconds[-1])
plt.legend()

plt.sca(axs[1])
plt.plot(freq_range_points, absolute_fft, color='c', label='FFT')
plt.xlim(freq_range_points[L[0]], freq_range_points[L[-1]])
plt.legend()

plt.sca(axs[2])
window = np.kaiser(len(amplitude), 0)
plt.plot(window)
plt.title("kaiser window")
plt.ylabel("Amplitude")
plt.xlabel("Sample")


plt.sca(axs[3])
A = np.fft.fft(window, len(amplitude)) / len(amplitude)
mag = np.abs(np.fft.fftshift(A))
freq = freq_range_points #np.linspace(-0.5, 0.5, len(A))
plt.plot(freq, mag, color='c', label='Hanning')

# response = 20 * np.log10(mag)
# response = np.clip(response, -100, 100)


plt.show()

#
# def compute_mainlobe_width(spectrum):
#     """
#     computes mainlobe width from spectrum
#
#     assumes the mainlobe starts at 0, that spectrum size is odd, and that
#     the spectrum is real-valued (half of the frequencies)
#
#     returns the number of samples of full mainlobe (not just half)
#     """
#     abs_spectrum = np.abs(spectrum)
#     current_value = abs_spectrum[0]
#     for ind, next_value in enumerate(abs_spectrum):
#         if next_value > current_value:
#             break
#         else:
#             current_value = next_value
#     return 2 * ind - 1
#
#
# def compute_sidelobe_level(spectrum):
#     """
#     computes sidelobe level from spectrum
#
#     assumes the mainlobe starts at 0, that spectrum size is odd, and that
#     the spectrum is real-valued (half of the frequencies)
#
#     returns the level of sidelobes in dB
#     """
#     mainlobe_width = compute_mainlobe_width(spectrum)
#
#     ind = (mainlobe_width - 1) / 2
#
#     abs_spectrum = np.abs(spectrum)
#
#     return 20 * np.log10(abs_spectrum[ind:].max() / abs_spectrum.max())
#
# for window in ['boxcar', 'hanning', 'hamming', 'blackman', 'blackmanharris']:
#     m = 513
#     w = get_window(window, m)
#     n = 4096
#     w_fft = np.fft.rfft(w, n)
#     freqs = np.fft.rfftfreq(n, d=1/m)
#     plt.figure(figsize=(10, 4))
#     plt.subplot(121)
#     plt.plot(t, w)
#     plt.xlabel("sample #")
#     plt.ylabel("amplitude")
#     plt.title("{} window".format(window))
#     plt.xlim(0, t.size)
#     plt.ylim(-0.025, 1.025)
#     plt.subplot(122)
#     plt.plot(freqs, 20*np.log10(np.abs(w_fft) / np.abs(w_fft).max()))
#     plt.xlim(0, 25)
#     plt.ylim(-120, 1)
#     width = compute_mainlobe_width(w_fft)
#     width_bins = width * m / n
#     level = compute_sidelobe_level(w_fft)
#     ylim_range = plt.ylim()
#     plt.vlines((width - 1) / 2 * m / n, ylim_range[0], ylim_range[1], lw=3)
#     xlim_range = plt.xlim()
#     plt.hlines(level, xlim_range[0], xlim_range[1], lw=3)
#     plt.title("{} window\nmainlobe width = {:.0f} bins, sidelobe level = {:.0f} dB".format(window,
#                                                                        width_bins,
#                                                                        level))
#     plt.xlabel('frequency bin #')