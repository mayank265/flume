# 0	0
# 1	90
# 0	180
# -1 270
# 0	360

import numpy as np
import matplotlib.pyplot as plt
import csv

plt.rcParams['figure.figsize'] = [16, 12]

dt = 0.001
t = np.arange(0, 1, dt)
n = len(t)

amplitude = np.sin(2 * np.pi * 25 * t)  + np.sin(2 * np.pi * 60 * t)  + 2*np.sin(2 * np.pi * 90 * t) # + np.sin(2 * np.pi * 120 * t)  # Clean Signal
f_clean = amplitude

print(len(t), len(amplitude))

# f = f + 2.5 * np.random.randn(len(t))  # Clean Frequency

# plt.plot(t, amplitude, color='c', label='Noisy')
# # plt.plot(t, f_clean, color='k', label='Clean')
# plt.xlim(t[0], t[-1])  # Time is on axis
# plt.legend()
# # plt.show()

# Compute the FFT

fhat = np.fft.fft(amplitude, n)

PSD = fhat * np.conj(fhat) / n

freq = (1 / (dt * n)) * np.arange(n)
print(np.arange(n))
print(len(fhat), len(PSD) , len(freq))
L = np.arange(1, np.floor((n / 2)), dtype='int')
print(L)
# Round off for better visibility

t = list(np.around(np.array(t), 3))
amplitude = list(np.around(np.array(amplitude), 3))
abs_fhat = list(np.around(np.array(abs(fhat)), 3))
# Write to file
import pandas

df = pandas.DataFrame(data={"Time": t, "Amplitude": amplitude, "FFT": fhat, "abs_FFT": abs_fhat, "PSD":PSD, "frequency": freq})
df.to_csv("file212.csv", sep=',', index=False)

fig, axs = plt.subplots(2, 1)

plt.sca(axs[0])
plt.plot(t, amplitude, color='c', label='Clean')
# plt.plot(t, f_clean, color='k', label='Clean')
plt.xlim(t[0], t[-1])
plt.legend()
# plt.show()

plt.sca(axs[1])
# plt.plot(freq[L], PSD[L], color='c', label='Noisy')
plt.plot(freq, abs_fhat , color='c', label='FFT')
# plt.plot(t,f_clean,color='k',label='Clean')
print(freq[L[-1]])
plt.xlim(freq[L[0]], freq[L[-1]])
plt.legend()
plt.show()
