import numpy as np
import matplotlib.pyplot as plt
import csv
import pandas
from scipy import signal


t = np.arange(0, 2, step=1/500)
m = t.size
print(m)
s = np.sin(2 * np.pi * 60 * t)
# print(t)
plt.plot(t, s)
plt.title("sinusoid, {} samples, sampling rate {} Hz".format(m, 1/(t[1] - t[0])))
plt.show()

fft_p = np.fft.fft(s)
plt.plot(abs(fft_p))
plt.show()

for window in ['boxcar', 'hamming', 'blackman']:
    n = m
    w = np.fft.rfft(s * signal.get_window(window, m), n=n)
    freqs = np.fft.rfftfreq(n, d=t[1] - t[0])
    plt.plot(freqs, 20*np.log10(np.abs(w)), label=window)
    # plt.loglog(freqs, np.abs(w), label=window)
# plt.ylim(-60, 60)
# plt.xlim(5, 300)
plt.legend()

plt.show()