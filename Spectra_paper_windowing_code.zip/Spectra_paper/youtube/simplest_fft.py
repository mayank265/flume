import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

import csv
import pandas

plt.rcParams['figure.figsize'] = [12, 8]

dt = 0.01  # 1/dt = Frequency
total_time_length_of_singal_in_seconds = np.arange(0, 10, dt)
n = len(total_time_length_of_singal_in_seconds)

amplitude =  np.sin(2 * np.pi * 30 * total_time_length_of_singal_in_seconds)
fft_amplitude = np.fft.fft(amplitude, n)
absolute_fft = abs(fft_amplitude)

freq_range_points = (1 / (dt * n)) * np.arange(n)  # freq is always 1/dt, but the granularity changes based on the time range of the we are inputting.

L = np.arange(1, np.floor((n / 2)), dtype='int')  # Plot half only as its mirror image

print(len(total_time_length_of_singal_in_seconds), len(amplitude), len(fft_amplitude), len(freq_range_points),
      (freq_range_points[L[-1]]), len(L))

df = pandas.DataFrame(
    data={"Time": total_time_length_of_singal_in_seconds, "Amplitude": amplitude, "FFT": fft_amplitude,
          "abs_FFT": absolute_fft, "frequency": freq_range_points})
df.to_csv("simplest_fft.csv", sep=',', index=False)
fig, axs = plt.subplots(4, 1)

plt.sca(axs[0])
plt.plot(total_time_length_of_singal_in_seconds, amplitude, color='c', label='Clean')
plt.xlim(total_time_length_of_singal_in_seconds[0], total_time_length_of_singal_in_seconds[-1])
plt.legend()

plt.sca(axs[1])
plt.plot(freq_range_points, absolute_fft, color='c', label='FFT')
plt.xlim(freq_range_points[L[0]], freq_range_points[L[-1]])
plt.legend()

plt.sca(axs[2])
window = np.hanning(len(amplitude))
plt.plot(window)
plt.title("Hann window")
plt.ylabel("Amplitude")
plt.xlabel("Sample")


plt.sca(axs[3])
A = np.fft.fft(window, len(amplitude)) / len(amplitude)
mag = np.abs(np.fft.fftshift(A))
freq = freq_range_points #np.linspace(-0.5, 0.5, len(A))
plt.plot(freq, mag, color='c', label='Hanning')

# response = 20 * np.log10(mag)
# response = np.clip(response, -100, 100)


plt.show()


for window in ['boxcar', 'hamming', 'blackman']:
    n = len(amplitude)
    w = np.fft.rfft(amplitude * signal.get_window(window, n), n=n)
    # freqs = np.fft.rfftfreq(n, d=t[1] - t[0])
    freqs = np.fft.rfftfreq(n, 0.01 )
    plt.plot(freqs, 20*np.log10(np.abs(w)), label=window)
    # plt.loglog(freqs, np.abs(w), label=window)
# plt.ylim(-60, 60)
# plt.xlim(5, 300)
plt.legend()

plt.show()