import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns; sns.set() # styling
m = 513
t = np.arange(m)

from scipy.signal import get_window

w = get_window('hamming', m)
plt.plot(t, w)
# print(t)
# print(w)

plt.xlabel("(time) sample #")
plt.ylabel("amplitude")
plt.title("hamming window")

plt.xlim(0, m-1)

plt.ylim(-0.025, 1.025)

plt.show()

# plt.ylim(min(w)-2, max(w)+1)

w_fft = np.fft.rfft(w)
freqs = np.fft.rfftfreq(w.size, d=1/m)
plt.plot(freqs, np.abs(w_fft))

plt.plot(freqs, np.abs(w_fft))
plt.xlim(0, 20)
n = 4096
w_fft = np.fft.rfft(w, n=4096)
freqs = np.fft.rfftfreq(n, d=1/m)
plt.plot(freqs, np.abs(w_fft))
plt.xlim(0, 20)
plt.show()